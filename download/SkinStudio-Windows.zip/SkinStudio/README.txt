﻿Скин-студия — редактор скинов Minecraft (версия 1.4.0)

Как запустить:
1. Распакуй архив (правой кнопкой → «Извлечь всё»), не запускай прямо из архива.
2. Открой SkinStudio.exe.
3. Если Windows покажет синее окно «Система Windows защитила ваш компьютер» —
   нажми «Подробнее» → «Выполнить в любом случае». Так бывает с любой программой
   без платной цифровой подписи.

Твои скины и настройки хранятся в папке %APPDATA%\SkinStudio.exe —
не переименовывай SkinStudio.exe, иначе программа начнёт с чистого листа.

Нужен Windows 10 или 11 (компонент WebView2 там уже стоит).

Не официальный продукт Minecraft. Не одобрен Mojang или Microsoft и не связан с ними.
NOT AN OFFICIAL MINECRAFT PRODUCT. NOT APPROVED BY OR ASSOCIATED WITH MOJANG OR MICROSOFT.

Программа сделана на Neutralino.js (MIT) — лицензии в THIRD-PARTY-NOTICES.txt.
